setwd("C:\\Users\\Welcome\\Desktop\\IT24104235")

x<-rnorm(25,mean=45,sd=2)
t.test(x,mu=46,alternative="less")